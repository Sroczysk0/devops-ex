package com.example.zadanie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZadanieApplicationTests {

	@Test
	void contextLoads() {
	}

}
